import $ from 'jquery';
import 'bootstrap'; // j'importe bootstrap.js depuis node_modules
// import owlCarousel from 'owl.carousel'; /* si il y a un carousel */



$(document).ready(function () {

  

});